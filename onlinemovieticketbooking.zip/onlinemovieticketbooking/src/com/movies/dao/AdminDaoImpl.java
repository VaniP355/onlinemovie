package com.movies.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import com.movies.dao.AdminDao;
import com.movies.dto.Show;
import com.movies.utils.AdminDBQueries;

public class AdminDaoImpl implements AdminDao {
	private Connection connection = null;
	private PreparedStatement pst;
	private ResultSet result;
	@Override
	public void openConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			connection = DriverManager.getConnection(url,"scott","tiger");
		} catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}		
	}
	@Override
	public void close() {                 
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	@Override
	public int addShow(Show show) {
		openConnection();
		int rows =0;
		try {
			//System.out.println();
		pst = connection.prepareStatement(AdminDBQueries.addShowQuery);
		pst.setLong(1,show.getShowId());

		pst.setTime(2,Time.valueOf(show.getShowStartTime()));
		pst.setTime(3,Time.valueOf(show.getShowEndTime()));
        pst.setString(4,show.getShowName());
        pst.setString(5, show.getMovieName());
        pst.setInt(6,show.getScreenId());
        pst.setInt(7,show.getTheaterId());
        rows = pst.executeUpdate();
		} catch (SQLException|NullPointerException e) {
			e.printStackTrace();
		}
		close();
		return rows;
	}
	@Override
	public int deleteShow(int showId) {
		openConnection();
		int rows = 0; 
		try {
			pst = connection.prepareStatement(AdminDBQueries.deleteShowQuery);
			pst.setLong(1,showId);
			rows = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rows;
	}
}

