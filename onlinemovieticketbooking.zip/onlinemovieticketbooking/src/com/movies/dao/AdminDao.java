package com.movies.dao;

import com.movies.dto.Show;

public interface AdminDao {
	public void openConnection();
	public void close();
	public int addShow(Show show);
	public int deleteShow(int showId);
}
