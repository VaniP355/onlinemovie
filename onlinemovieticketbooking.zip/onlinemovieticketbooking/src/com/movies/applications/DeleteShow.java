package com.movies.applications;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import com.movies.dao.AdminDao;
import com.movies.dao.AdminDaoImpl;
import com.movies.dto.Show;
import com.movies.service.AdminService;
import com.movies.service.AdminServiceImpl;

public class DeleteShow {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader sc=new BufferedReader(new InputStreamReader(System.in)); 
		AdminService service = new AdminServiceImpl();
	    AdminDao dao=new AdminDaoImpl();
		System.out.println("enter show id to be deleted");
		int showId = Integer.parseInt(sc.readLine());
		Show s = new Show();
		s.setShowId(showId);
		int rows = service.deleteShow(showId);
		if(rows>=0)
			System.out.println("Show deleted");
		else
			System.out.println("Show Not deleted");
	}

}
