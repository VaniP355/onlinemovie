package com.movies.applications;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalTime;
import java.util.Scanner;

import com.movies.dto.Show;
import com.movies.service.AdminService;
import com.movies.service.AdminServiceImpl;
import com.movies.utils.ConvertTime;

public class AddShow 
{
	public static void main(String[] args) throws NumberFormatException, IOException 
	{
		
		BufferedReader sc=new BufferedReader(new InputStreamReader(System.in)); 
		AdminService service = new AdminServiceImpl();
		System.out.println("enter show id");
		int showId;
		showId = Integer.parseInt(sc.readLine());
		Scanner scan=new Scanner(System.in);
		System.out.println("enter show start time");
		String startTime=scan.next();  //default format: hh:mm:ss
		LocalTime lt=LocalTime.parse(startTime);
		System.out.println("enter show end time");
		String endTime=scan.next();  //default format: hh:mm:ss
		LocalTime lt1=LocalTime.parse(endTime);
		System.out.println("enter show name");		
		String showName=sc.readLine();
		System.out.println("enter movie name");
		String movieName=sc.readLine();
		System.out.println("enter screen id");
		int screenId=Integer.parseInt(sc.readLine());
		System.out.println("enter theatre id");
		int theatreId=Integer.parseInt(sc.readLine());
		Show show=new Show(showId,ConvertTime.convertToTime(startTime),ConvertTime.convertToTime(endTime),showName,movieName,screenId,theatreId);
		int rows=service.addShow(show);
		System.out.println("nn");
		if(rows>0)
			System.out.println("show added");
		else
			System.out.println("show not added");
	}
}
