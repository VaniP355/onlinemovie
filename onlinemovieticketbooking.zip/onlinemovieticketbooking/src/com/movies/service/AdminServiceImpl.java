package com.movies.service;

import com.movies.dao.AdminDao;
import com.movies.dao.AdminDaoImpl;
import com.movies.dto.Show;

public class AdminServiceImpl implements AdminService {
	AdminDao dao = new AdminDaoImpl();

	@Override
	public int addShow(Show show) {
	    int rows = dao.addShow(show);
		return rows;
	}

	@Override
	public int deleteShow(int showId) {
		int rows = dao.deleteShow(showId);
		return rows;
	}

}

