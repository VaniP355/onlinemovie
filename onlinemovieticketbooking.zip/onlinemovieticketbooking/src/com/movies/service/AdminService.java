package com.movies.service;

import com.movies.dto.Show;

public interface AdminService {
	public int addShow(Show show);
	public int deleteShow(int showId);
}
