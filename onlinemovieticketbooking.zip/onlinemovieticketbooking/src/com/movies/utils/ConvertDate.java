package com.movies.utils;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
	public class ConvertDate {
			public static Date utildate = null;
			public static Date convertDate(String date) {
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			 try {
				 utildate = sdf.parse(date);
			 }catch(ParseException e) {
				 e.printStackTrace();
			 }
	         return utildate;
		}

	}



