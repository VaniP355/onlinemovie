package com.movies.utils;
import java.time.LocalTime;
public class ConvertTime 
{
     public static LocalTime convertToTime(String time)
     {
    	 String[] s = time.split(":");
    	 return LocalTime.of(Integer.parseInt(s[0]),Integer.parseInt(s[1]),Integer.parseInt(s[2]));
     }
}
