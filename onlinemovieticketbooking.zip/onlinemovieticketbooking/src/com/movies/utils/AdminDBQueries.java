package com.movies.utils;

public class AdminDBQueries {
	public static String addShowQuery = "insert into show values(?,?,?,?,?,?,?)";
	public static String deleteShowQuery = "delete from show where showId = ?";

}
