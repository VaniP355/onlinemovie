package com.movies.dto;

public class Seat {
	private int seatId;
	//private Enum seatStatus;
	private Double seatPrice;
	public Seat() {	}
	public Seat(int seatId,Double seatPrice) {
		this.seatId = seatId;
		//this.seatStatus = seatStatus;
		this.seatPrice = seatPrice;
	}
	public int getSeatId() {
		return seatId;
	}
	public void setSeatId(int seatId) {
		this.seatId = seatId;
	}
	/*public Enum getSeatStatus() {
		return seatStatus;
	}*/
	/*public void setSeatStatus(Enum seatStatus) {
		this.seatStatus = seatStatus;
	}*/
	public Double getSeatPrice() {
		return seatPrice;
	}
	public void setSeatPrice(Double seatPrice) {
		this.seatPrice = seatPrice;
	}
}
